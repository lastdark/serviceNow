package com.unicredit.credential;

import com.unicredit.utility.PropertiesLoader;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Properties;

public class Credential {


    public static String buildBasic(){
        Properties properties=PropertiesLoader.load (Credential.class,"config" );
        String user= properties.getProperty ( "user" );
        String password=properties.getProperty ( "password" );

        byte[] encodedGrants = Base64.getEncoder().encode((user + ":" + password).getBytes());
        String basic= "Basic " + new String(encodedGrants, StandardCharsets.UTF_8);
        return basic;

    }

}
