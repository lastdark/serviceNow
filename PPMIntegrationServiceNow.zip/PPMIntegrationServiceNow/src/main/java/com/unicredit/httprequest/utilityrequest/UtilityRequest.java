package com.unicredit.httprequest.utilityrequest;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;

import java.util.Map;

public class UtilityRequest {


    public static void setHeader(RequestBuilder requestBuilder, Map<String,String> headers ){

        for(Map.Entry<String,String> entry:headers.entrySet()){

            requestBuilder.setHeader(entry.getKey(),entry.getValue());
        }

    }

    public static HttpEntity createDataJson(String data ){

        HttpEntity httpEntity=new StringEntity(data, ContentType.APPLICATION_JSON);
        return  httpEntity;
    }


}
