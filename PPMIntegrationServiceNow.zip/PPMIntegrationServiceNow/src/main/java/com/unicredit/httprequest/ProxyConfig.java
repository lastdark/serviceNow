package com.unicredit.httprequest;

import com.unicredit.utility.PropertiesLoader;
import org.apache.http.HttpHost;

import java.util.Properties;

public class ProxyConfig {





    public static HttpHost build(){

        Properties properties=PropertiesLoader.load(ProxyConfig.class,"config");

        HttpHost proxy = new HttpHost( properties.getProperty("url"), Integer.parseInt(properties.getProperty("port")), properties.getProperty("protocol"));
        return  proxy;
    }
    public static HttpHost build(String url,int port,String protocol){


        HttpHost proxy = new HttpHost( url, port,protocol);
        return  proxy;
    }
}
