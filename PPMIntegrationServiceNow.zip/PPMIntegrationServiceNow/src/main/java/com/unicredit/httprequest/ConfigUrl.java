package com.unicredit.httprequest;

import com.unicredit.utility.PropertiesLoader;

import java.util.Properties;

public class ConfigUrl {


    public static String buildUrl(String instanceName){
        String url="";
        Properties properties= PropertiesLoader.load ( ConfigUrl.class,"config");

        url=properties.getProperty ( "url");
      //  url=url.replaceAll("<instancename>", properties.getProperty (instanceName));

        url=url.replaceAll("<instancename>", instanceName);
        return url;
    }



}
