package com.unicredit.httprequest;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;

import java.util.Map;


import static com.unicredit.httprequest.utilityrequest.UtilityRequest.createDataJson;
import static com.unicredit.httprequest.utilityrequest.UtilityRequest.setHeader;

public class HttpRequest {




    public static HttpUriRequest patchMethod( String url, HttpHost proxy, Map <String,String> headers , String data){

        RequestBuilder requestBuilder = RequestBuilder.patch(url);
        RequestConfig defaultRequestConfig=null;

        if(proxy!=null){

            defaultRequestConfig = RequestConfig.custom().setProxy(proxy).build();
        }
        if(headers!=null){

            setHeader(requestBuilder,headers);
        }

        if(data!=null){

            requestBuilder.setEntity(createDataJson(data));
        }

         if(defaultRequestConfig!=null) {
             requestBuilder.setConfig ( defaultRequestConfig );

         }

        return requestBuilder.build();
    }
}
