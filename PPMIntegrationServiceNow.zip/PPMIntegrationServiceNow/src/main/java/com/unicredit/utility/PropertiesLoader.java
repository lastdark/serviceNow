package com.unicredit.utility;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesLoader {


    public static Properties load ( Class < ? > classPropertiesFile , String path ) {

        String nameResource = "";
        if ( path != "" ) {

            nameResource = path + "/" + classPropertiesFile.getSimpleName ( ) + ".properties";
        } else {

            nameResource = classPropertiesFile.getSimpleName ( ) + ".properties";
        }

        // URL url = classPropertiesFile.getClassLoader().getResource(nameResource);

        InputStream ioStream = classPropertiesFile.getClassLoader ( ).getResourceAsStream ( nameResource );

        Properties properties = new Properties ( );

        try {

            properties.load ( ioStream );

        } catch ( IOException e ) {


        }

        return properties;

    }
}

