package com.unicredit;
import com.google.gson.Gson;
import com.unicredit.bootstrap.Bootstrap;
import com.unicredit.bootstrap.runtimeException.BootStrapException;
import com.unicredit.credential.Credential;
import com.unicredit.httprequest.ConfigUrl;
import com.unicredit.httprequest.HttpRequest;
import com.unicredit.httprequest.ProxyConfig;
import com.unicredit.httpresponse.JsonResponseHandler;
import com.unicredit.servicenow.httpBodyRequest.RequestBody;
import com.unicredit.utility.PropertiesLoader;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class Main {
    public static void main ( String[] args ) {

        if ( args.length == 0 ) {


            System.err.println ( "Not select  mode start" );
            System.exit ( -1 );
        }
        Bootstrap bootstrap = new Bootstrap ( );
        System.out.println ( "operation executive description :" );
        String mode = TypeMode ( args[0] );

        if ( bootstrap.build ( mode , args ) ) {
            int code = bootstrap.start ( );

            System.exit ( code );


        }

    }

    public  static String TypeMode(String type){

        String mode=type.toUpperCase ( );

        switch (mode) {
            case "D":{


                return "DEVELOPMENT";
            }
            case "T": {


              return "TEST";
            }
            case "P": {


                return "PRODUCTION";
            }

            default: {

                return "Invalid args digit("+type+")" ;
            }
        }

    }
}
