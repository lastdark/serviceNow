package com.unicredit.bootstrap.runtimeException;

public class BootStrapException extends RuntimeException{

    public BootStrapException () {
    }

    public BootStrapException ( String message ) {
        super ( message );
    }
}
