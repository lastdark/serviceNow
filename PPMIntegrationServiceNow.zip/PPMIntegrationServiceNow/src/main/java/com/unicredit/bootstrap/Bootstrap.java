package com.unicredit.bootstrap;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.unicredit.bootstrap.runtimeException.BootStrapException;
import com.unicredit.credential.Credential;
import com.unicredit.httprequest.ConfigUrl;
import com.unicredit.httprequest.HttpRequest;
import com.unicredit.httprequest.ProxyConfig;
import com.unicredit.httpresponse.JsonResponseHandler;
import com.unicredit.httpresponse.ResponseBody;
import com.unicredit.servicenow.httpBodyRequest.RequestBody;
import com.unicredit.utility.PropertiesLoader;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Bootstrap {


    private CloseableHttpClient httpclient;
    private Map < String, String > logBootStrap;
    private Gson gson;
    private HttpUriRequest patchRequest;

    public Bootstrap () {


        httpclient = HttpClients.createDefault ( );
        this.logBootStrap = init ( );
        this.gson = new Gson ( );
        patchRequest = null;

    }

    private Map < String, String > init () {


        return new HashMap <> ( );
    }

    public boolean build ( String mode , String args[] ) {

        HttpHost proxy = ProxyConfig.build ( );

        String urlS = ConfigUrl.buildUrl ( mode ( mode ) );

        System.out.println ( urlS );
        logBootStrap.put ( "url" , urlS );
        logBootStrap.put ( "proxy" , proxy.toString ( ) );
        try {
            RequestBody requestBody = create ( args );
            logBootStrap.put ( "obj" , requestBody.toString ( ) );
            Map < String, String > headers = createHeader ( );
            logBootStrap.put ( "headers" , headers.toString ( ) );
            String dataPatchJson = gson.toJson ( requestBody );
            logBootStrap.put ( "json" , dataPatchJson );
            patchRequest = HttpRequest.patchMethod ( urlS , proxy , headers , dataPatchJson );
            logBootStrap.put ( "typeRequest" , patchRequest.getMethod () );
            return  true;

        } catch ( BootStrapException e ) {

            System.err.println ( e.getMessage ( ) );
            System.exit ( -1 );

        } catch ( NumberFormatException e ) {
            String message = String.format ( "required number" + e.getMessage ( ) );
            System.err.println ( message );
            System.exit ( -2 );

        }
        return false;
    }


    public int  start()
     {      int codeStatus=-1;
           try {
              ResponseHandler <String> responseHandler = new JsonResponseHandler ();
              String json=httpclient.execute ( patchRequest,responseHandler);
              //JSONObject result = new JSONObject(json);
              JsonObject jsonResp = gson.fromJson(json, JsonObject.class);
              System.out.println ( toString ());
              JsonElement element=  jsonResp.get ( "result" );
             String el= element.getAsJsonObject ().get ( "status_code" ).getAsString ();
             String el1= element.getAsJsonObject ().get ( "message" ).getAsString ();
              ResponseBody responseBody=ResponseBody.createResponse (el,el1 );

              codeStatus=Integer.parseInt ( el );

            System.out.println (responseBody);

          }catch ( IOException  e){

              System.err.println ( e.getMessage () );
              System.exit ( -5 );

          }

           return codeStatus;
    }



    private Map < String, String > createHeader () {


        Map < String, String > headers = new HashMap ( );
        headers.put ( HttpHeaders.CONTENT_TYPE , "application/json" );
        headers.put ( HttpHeaders.AUTHORIZATION , Credential.buildBasic ( ) );

        return headers;
    }

    private RequestBody create ( String... args ) {
        RequestBody requestBody = null;
        switch (args.length) {
            case 0:
            case 1:
            case 2: {


                throw new BootStrapException ( "number args min args 2" );

            }

            case 3:
            case 4:
            {


                    requestBody = new RequestBody ( args[1] ,  args[2] ) ;


                    if ( args.length == 4 ) {
                        if ( args[3].isEmpty ( ) ) {

                            //requestBody.setU_project ( args[3] );
                        } else {
                            requestBody.setU_project ( args[3] );
                        }

                    }



            }
            break;
            default: {

                throw new BootStrapException ( "number args max 4" );
            }
        }

        return requestBody;
    }


    private String mode ( String mode ) {

        //"DEVELOPMENT"
        Properties properties = PropertiesLoader.load ( Bootstrap.class , "" );
        return properties.getProperty ( mode );

    }



    private boolean isNumeric(String value){

        boolean isNumeric = (value != null && value.matches("[0-9]+"));
        return  isNumeric;

    }
 //
    @Override
    public String toString () {

        String proxy = logBootStrap.get ( "proxy" );
        String url = logBootStrap.get ( "url" );
        String typeRequest=logBootStrap.get ("typeRequest" );
        String data=logBootStrap.get ( "json" );

        return "[" +
                "{Proxy :" + proxy + "}," + "\n"+
                "{URL :" + url + "}," + "\n" +
                "{TypeRequest :" + typeRequest + "}," + "\n"+
                "{data-json :" + data + "}," + "\n"+
                "]";

    }
}