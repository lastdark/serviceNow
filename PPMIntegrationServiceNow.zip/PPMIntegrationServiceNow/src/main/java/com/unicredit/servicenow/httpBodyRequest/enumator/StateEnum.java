package com.unicredit.servicenow.httpBodyRequest.enumator;

public enum StateEnum {


    NEW(1,"New"), REQUEST_TO_BE_COMPTED(2,"Request to be Completed"),  REQUEST_IN_EVALUATION(3,"Request in evaluation"),BUILDING_SOLUTION(4,"Building solution"),
    CLOSED(5,"Closed"),REVIEWING_COST_ESTIMATION(6,"Reviewing Cost estimation"),REQUEST_CANCELLED(7,"Request Cancelled"),REVIEWING_SOLUTION(8,"Reviewing Solution"),
    WAITING_FOR_PPM_BUDGET_APPROVAL(9,"Waiting for PPM budget approval"),BUDGET_APPROVED(10,"Budget approved"),PENDING_DELIVERY(12,"Pending delivery"),DELIVERED(13,"Delivered")
    ;



    private int state;
    private String comment;

    StateEnum(int state, String comment) {
        this.state = state;
        this.comment = comment;
    }

    public int getState() {
        return state;
    }

    public String getComment() {
        return comment;
    }

    public  static  StateEnum getCommentCode(int state){

        for(StateEnum stateEnum : StateEnum.values() ) {
            if(stateEnum.state == state) {
                return stateEnum;
            }
        }
        return null;
    }

}
