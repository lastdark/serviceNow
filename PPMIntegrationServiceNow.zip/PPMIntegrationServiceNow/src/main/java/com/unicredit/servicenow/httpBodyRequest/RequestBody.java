package com.unicredit.servicenow.httpBodyRequest;

import com.unicredit.servicenow.httpBodyRequest.enumator.StateEnum;

public class RequestBody {


    private String sys_id;
    private  String  state;
    private String u_project;
    private  String comments;


    public  RequestBody(){
    }

    public RequestBody(String sys_id, String  state) {
        this.sys_id = sys_id;
        this.state = state;

         if(isNumeric ( state )){

             StateEnum stateEnum=StateEnum.getCommentCode (Integer.parseInt (  state ));
             this.comments=stateEnum.getComment ();

         }

    }



    private boolean isNumeric(String value){

        boolean isNumeric = (value != null && value.matches("[0-9]+"));
        return  isNumeric;

    }



    public String getSys_id() {
        return sys_id;
    }

    public void setSys_id(String sys_id) {
        this.sys_id = sys_id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getU_project() {
        return u_project;
    }

    public void setU_project(String u_project) {
        this.u_project = u_project;
    }

    public String getComments() {
        return comments;
    }

    public void setComments() {
        this.comments = StateEnum.getCommentCode(Integer.parseInt ( this.state )).getComment();
    }

    public void setComments(String comments) {
        this.comments = comments;
    }



}
