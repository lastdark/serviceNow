package com.unicredit.httpresponse;


import java.util.Map;

public class ResponseBody {


    private String status_code;
    private String message;

    public ResponseBody () {
    }


    public void setStatus_code ( String status_code ) {
        this.status_code = status_code;
    }

    public void setMessage ( String message ) {
        this.message = message;
    }

    public String getStatus_code () {
        return status_code;
    }

    public String getMessage () {
        return message;
    }

    public static ResponseBody createResponse( String status_code ,String message){


       ResponseBody responseBody=new ResponseBody ();
       responseBody.setStatus_code (  convertStatus (status_code));
       responseBody.setMessage ( message );
       return  responseBody;


    }


    private static String   convertStatus(String code){




        switch (Integer.parseInt ( code )) {
            case 200:{


                return  "0";
            }
            case 400: {

              return  "1";
            }

            case 403:{


                return "2";
            }
            case  404:{

                return " 3";

            }
            case 500: {

                return  "4";
            }

            default: {

               return  "error code not valid";
            }
        }

    }


    @Override
    public String toString () {
        return  "{"+ "Outcome :"+ "status_code : " + status_code  + ", message :"  + message+ "}";
    }
}