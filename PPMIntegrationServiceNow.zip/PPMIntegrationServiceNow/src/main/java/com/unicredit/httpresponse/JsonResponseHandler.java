package com.unicredit.httpresponse;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.util.EntityUtils;

import java.io.IOException;

public class JsonResponseHandler implements ResponseHandler < String > {
    @Override
    public String handleResponse ( HttpResponse response ) {
        String responseResult = "";

        try {


            HttpEntity entity = response.getEntity ( );
            responseResult = EntityUtils.toString ( entity );




        } catch ( ClientProtocolException e ) {

            System.err.println ( e.getMessage ( ) );
        } catch ( IOException e ) {

            System.err.println ( e.getMessage ( ) );
        }

        return responseResult;
    }


}

